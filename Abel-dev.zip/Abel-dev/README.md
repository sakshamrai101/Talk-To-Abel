# Abel
## The next-generation educational AI platform.

Abel is a unique way to engage with AI. It's conversational, natural, and kid-friendly. Users can chat with a variety of "personalities", or create their own. Use it to roleplay magical adventures with Theo the knight and renowed pirate Flynn Seaborne, closer-to-reality scenarios with Brayden the gamer and Mason the fitness buff, or use our custom prompting tool to experiment with advanced AI. You've never chatted like this before.