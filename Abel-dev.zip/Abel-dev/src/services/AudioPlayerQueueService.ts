import AudioPlayerQueue from "./AudioPlayerQueue";

export const audioPlayerQueue = new AudioPlayerQueue()
