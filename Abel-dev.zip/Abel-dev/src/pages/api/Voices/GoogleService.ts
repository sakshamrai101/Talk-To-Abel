import { GoogleTTS } from 'pages/api/Voices/GoogleTTS'

export const TTS = new GoogleTTS()
